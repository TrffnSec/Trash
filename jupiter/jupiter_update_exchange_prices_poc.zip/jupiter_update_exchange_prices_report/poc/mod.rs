//! Vault tests module
//!
//! This module contains tests for the vaults program.

pub mod base_test;
pub mod combination_test;
pub mod fixture;
pub mod liquidate_test;
pub mod update_exchange_prices_frequency_test;
pub mod update_exchange_prices_borrow_impact_test;
pub mod update_exchange_prices_borrow_probe_test;
pub mod update_exchange_prices_extra_borrow_scan_test;
