//! Regression/PoC gate for public update_exchange_prices frequency sensitivity.
//!
//! Goal:
//! Same vault config, same total elapsed time.
//! Path A: one update after 30 days.
//! Path B: daily public updates for 30 days.
//!
//! Expected:
//! Path B stores a higher vault_supply_exchange_price than Path A when
//! supply_rate_magnifier is positive.

#[cfg(test)]
mod tests {
    use crate::vaults::fixture::{VaultFixture, DEFAULT_ORACLE_PRICE};
    use fluid_test_framework::StateManager;

    const VAULT_ID: u16 = 1;
    const SUPPLY_RATE_MAGNIFIER: i16 = 368;
    const ONE_DAY_SECONDS: i64 = 24 * 60 * 60;
    const DAYS: usize = 30;

    fn setup_vault_fixture() -> VaultFixture {
        let mut fixture = VaultFixture::new().expect("Failed to create vault fixture");
        fixture.setup().expect("Failed to setup vault fixture");

        fixture
            .set_oracle_price(DEFAULT_ORACLE_PRICE, true)
            .expect("Failed to set oracle price");

        fixture
    }

    fn one_shot_after_30_days() -> u64 {
        let mut fixture = setup_vault_fixture();

        fixture
            .update_supply_rate_magnifier(VAULT_ID, SUPPLY_RATE_MAGNIFIER)
            .expect("Failed to set supply rate magnifier");

        fixture
            .liquidity
            .vm
            .warp_time(ONE_DAY_SECONDS * DAYS as i64);

        fixture
            .update_exchange_prices_public(VAULT_ID)
            .expect("Failed to public update exchange prices once");

        let state = fixture
            .read_vault_state(VAULT_ID)
            .expect("Failed to read vault state");

        state.supply_exchange_price
    }

    fn repeated_daily_updates_for_30_days() -> u64 {
        let mut fixture = setup_vault_fixture();

        fixture
            .update_supply_rate_magnifier(VAULT_ID, SUPPLY_RATE_MAGNIFIER)
            .expect("Failed to set supply rate magnifier");

        for _ in 0..DAYS {
            fixture.liquidity.vm.warp_time(ONE_DAY_SECONDS);

            fixture
                .update_exchange_prices_public(VAULT_ID)
                .expect("Failed to public update exchange prices daily");
        }

        let state = fixture
            .read_vault_state(VAULT_ID)
            .expect("Failed to read vault state");

        state.supply_exchange_price
    }

    #[test]
    fn test_public_update_exchange_price_frequency_divergence() {
        let one_shot_price = one_shot_after_30_days();
        let repeated_price = repeated_daily_updates_for_30_days();

        println!("one_shot_supply_exchange_price={}", one_shot_price);
        println!("repeated_supply_exchange_price={}", repeated_price);
        println!(
            "delta_repeated_minus_one_shot={}",
            repeated_price as i128 - one_shot_price as i128
        );

        assert!(
            repeated_price > one_shot_price,
            "Expected repeated public updates to store a higher supply exchange price than one delayed update"
        );
    }
}
