//! Quantification scan for the 730d public update_exchange_prices borrow impact.
//!
//! This test uses the already-proven one-shot max from the passing PoC and
//! checks how much more debt the repeated public-update schedule can borrow.

#[cfg(test)]
mod tests {
    use crate::vaults::fixture::{OperateVars, VaultFixture, DEFAULT_ORACLE_PRICE};
    use fluid_test_framework::StateManager;

    const VAULT_ID: u16 = 1;
    const POSITION_ID: u32 = 1;

    const SUPPLY_RATE_MAGNIFIER: i16 = 368;

    const ONE_DAY_SECONDS: i64 = 24 * 60 * 60;
    const DAYS: usize = 730;

    const COLLATERAL_AMOUNT: i128 = 1_000_000_000;

    // From the passing one-shot boundary PoC.
    const ONE_SHOT_MAX_SUCCESSFUL_DEBT: i128 = 858_228_098;

    // Descending offsets to quantify impact. Expected useful region is around
    // the supply-price delta ratio, but tick rounding may shift it.
    const OFFSETS_DESC: [i128; 12] = [
        5_000_000,
        4_000_000,
        3_000_000,
        2_500_000,
        2_000_000,
        1_500_000,
        1_000_000,
        750_000,
        500_000,
        250_000,
        100_000,
        1,
    ];

    fn setup_vault_fixture() -> VaultFixture {
        let mut fixture = VaultFixture::new().expect("Failed to create vault fixture");
        fixture.setup().expect("Failed to setup vault fixture");

        fixture
            .set_oracle_price(DEFAULT_ORACLE_PRICE, true)
            .expect("Failed to set oracle price");

        fixture
    }

    fn open_existing_position_before_schedule() -> (VaultFixture, solana_sdk::signature::Keypair) {
        let mut fixture = setup_vault_fixture();
        let alice = fixture.liquidity.alice.insecure_clone();

        fixture
            .update_supply_rate_magnifier(VAULT_ID, SUPPLY_RATE_MAGNIFIER)
            .expect("Failed to set supply rate magnifier");

        fixture
            .init_position(VAULT_ID, &alice)
            .expect("Failed to init position");

        fixture
            .operate_vault(&OperateVars {
                vault_id: VAULT_ID,
                position_id: POSITION_ID,
                user: &alice,
                position_owner: &alice,
                collateral_amount: COLLATERAL_AMOUNT,
                debt_amount: 0,
                recipient: &alice,
            })
            .expect("Failed to deposit baseline collateral");

        (fixture, alice)
    }

    fn apply_repeated_schedule(fixture: &mut VaultFixture) {
        for _ in 0..DAYS {
            fixture.liquidity.vm.warp_time(ONE_DAY_SECONDS);

            fixture
                .update_exchange_prices_public(VAULT_ID)
                .expect("Failed to public update exchange prices daily");
        }

        fixture
            .set_oracle_price(DEFAULT_ORACLE_PRICE, true)
            .expect("Failed to refresh oracle price after warp");
    }

    fn repeated_candidate_ok(candidate_debt: i128) -> bool {
        let (mut fixture, alice) = open_existing_position_before_schedule();

        apply_repeated_schedule(&mut fixture);

        let state_after = fixture
            .read_vault_state(VAULT_ID)
            .expect("Failed to read repeated state");

        let res = fixture.operate_vault(&OperateVars {
            vault_id: VAULT_ID,
            position_id: POSITION_ID,
            user: &alice,
            position_owner: &alice,
            collateral_amount: 0,
            debt_amount: candidate_debt,
            recipient: &alice,
        });

        println!(
            "candidate_debt={} offset={} repeated_supply_price={} repeated_borrow_price={} repeated_result={:?}",
            candidate_debt,
            candidate_debt - ONE_SHOT_MAX_SUCCESSFUL_DEBT,
            state_after.supply_exchange_price,
            state_after.borrow_exchange_price,
            res
        );

        res.is_ok()
    }

    #[test]
    fn test_730d_extra_borrow_offset_scan() {
        println!("collateral_amount={}", COLLATERAL_AMOUNT);
        println!("one_shot_max_successful_debt={}", ONE_SHOT_MAX_SUCCESSFUL_DEBT);

        let mut best_offset = 0;
        let mut best_candidate = ONE_SHOT_MAX_SUCCESSFUL_DEBT;

        for offset in OFFSETS_DESC {
            let candidate = ONE_SHOT_MAX_SUCCESSFUL_DEBT + offset;

            if repeated_candidate_ok(candidate) {
                best_offset = offset;
                best_candidate = candidate;
                break;
            }
        }

        println!("BEST_EXTRA_BORROW_OFFSET_LOWER_BOUND={}", best_offset);
        println!("BEST_EXTRA_BORROW_CANDIDATE_LOWER_BOUND={}", best_candidate);

        assert!(
            best_offset > 0,
            "Repeated schedule did not allow any tested extra-borrow offset"
        );
    }
}
